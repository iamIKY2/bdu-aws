import { useState } from 'react'
import Register from './components/Register'
import ManageProfiles from './components/ManageProfiles'
import UploadDocuments from './components/UploadDocuments'
import SearchResults from './components/SearchResults'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('register')

  return (
    <div>
      <h1>🎓 Hệ thống Tuyển sinh BDU</h1>
      
      <div className="container">
        <div className="nav">
          <button onClick={() => setActiveTab('register')}>
            Đăng ký thông tin
          </button>
          <button onClick={() => setActiveTab('manage')}>
            Quản lý hồ sơ
          </button>
          <button onClick={() => setActiveTab('upload')}>
            Upload tài liệu
          </button>
          <button onClick={() => setActiveTab('search')}>
            Tra cứu kết quả
          </button>
        </div>

        {activeTab === 'register' && <Register />}
        {activeTab === 'manage' && <ManageProfiles />}
        {activeTab === 'upload' && <UploadDocuments />}
        {activeTab === 'search' && <SearchResults />}
      </div>
    </div>
  )
}

export default App

