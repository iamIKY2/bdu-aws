import { useState } from 'react'
import axios from 'axios'

function Register() {
  const [formData, setFormData] = useState({
    ho_ten: '',
    ngay_sinh: '',
    gioi_tinh: 'Nam',
    cmnd_cccd: '',
    email: '',
    so_dien_thoai: '',
    dia_chi: '',
    nganh_dang_ky: '',
    khoi_thi: ''
  })
  const [message, setMessage] = useState({ type: '', text: '' })

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setMessage({ type: '', text: '' })

    try {
      const response = await axios.post('/api/candidates/register', formData)
      setMessage({ type: 'success', text: response.data.message })
      // Reset form
      setFormData({
        ho_ten: '',
        ngay_sinh: '',
        gioi_tinh: 'Nam',
        cmnd_cccd: '',
        email: '',
        so_dien_thoai: '',
        dia_chi: '',
        nganh_dang_ky: '',
        khoi_thi: ''
      })
    } catch (error) {
      setMessage({
        type: 'error',
        text: error.response?.data?.message || 'Có lỗi xảy ra khi đăng ký'
      })
    }
  }

  return (
    <div>
      <h2>Đăng ký thông tin tuyển sinh</h2>
      
      {message.text && (
        <div className={`alert alert-${message.type === 'success' ? 'success' : 'error'}`}>
          {message.text}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="grid-2">
          <div className="form-group">
            <label>Họ và tên *</label>
            <input
              type="text"
              name="ho_ten"
              value={formData.ho_ten}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Ngày sinh *</label>
            <input
              type="date"
              name="ngay_sinh"
              value={formData.ngay_sinh}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Giới tính *</label>
            <select
              name="gioi_tinh"
              value={formData.gioi_tinh}
              onChange={handleChange}
              required
            >
              <option value="Nam">Nam</option>
              <option value="Nữ">Nữ</option>
              <option value="Khác">Khác</option>
            </select>
          </div>

          <div className="form-group">
            <label>CMND/CCCD *</label>
            <input
              type="text"
              name="cmnd_cccd"
              value={formData.cmnd_cccd}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Email *</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Số điện thoại *</label>
            <input
              type="tel"
              name="so_dien_thoai"
              value={formData.so_dien_thoai}
              onChange={handleChange}
              required
            />
          </div>
        </div>

        <div className="form-group">
          <label>Địa chỉ *</label>
          <textarea
            name="dia_chi"
            value={formData.dia_chi}
            onChange={handleChange}
            rows="3"
            required
          />
        </div>

        <div className="grid-2">
          <div className="form-group">
            <label>Ngành đăng ký *</label>
            <input
              type="text"
              name="nganh_dang_ky"
              value={formData.nganh_dang_ky}
              onChange={handleChange}
              placeholder="Ví dụ: Công nghệ thông tin"
              required
            />
          </div>

          <div className="form-group">
            <label>Khối thi *</label>
            <select
              name="khoi_thi"
              value={formData.khoi_thi}
              onChange={handleChange}
              required
            >
              <option value="">Chọn khối thi</option>
              <option value="A00">A00 (Toán, Lý, Hóa)</option>
              <option value="A01">A01 (Toán, Lý, Anh)</option>
              <option value="B00">B00 (Toán, Hóa, Sinh)</option>
              <option value="C00">C00 (Văn, Sử, Địa)</option>
              <option value="D01">D01 (Toán, Văn, Anh)</option>
              <option value="D07">D07 (Toán, Hóa, Anh)</option>
            </select>
          </div>
        </div>

        <button type="submit">Đăng ký</button>
      </form>
    </div>
  )
}

export default Register

