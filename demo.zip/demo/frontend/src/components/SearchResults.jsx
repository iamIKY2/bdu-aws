import { useState } from 'react'
import axios from 'axios'

function SearchResults() {
  const [cmnd, setCmnd] = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState({ type: '', text: '' })

  const handleSearch = async (e) => {
    e.preventDefault()
    setMessage({ type: '', text: '' })
    setResult(null)

    if (!cmnd.trim()) {
      setMessage({
        type: 'error',
        text: 'Vui lòng nhập CMND/CCCD để tra cứu'
      })
      return
    }

    setLoading(true)
    try {
      const response = await axios.get(`/api/results/search/cmnd/${cmnd}`)
      setResult(response.data.data)
      setMessage({ type: 'success', text: 'Tìm thấy kết quả' })
    } catch (error) {
      setMessage({
        type: 'error',
        text: error.response?.data?.message || 'Không tìm thấy kết quả'
      })
      setResult(null)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <h2>Tra cứu kết quả tuyển sinh</h2>
      
      {message.text && (
        <div className={`alert alert-${message.type === 'success' ? 'success' : 'error'}`}>
          {message.text}
        </div>
      )}

      <form onSubmit={handleSearch} style={{ marginBottom: '30px' }}>
        <div className="form-group">
          <label>Nhập số CMND/CCCD để tra cứu</label>
          <div style={{ display: 'flex', gap: '10px' }}>
            <input
              type="text"
              value={cmnd}
              onChange={(e) => setCmnd(e.target.value)}
              placeholder="Ví dụ: 001234567890"
              style={{ flex: 1 }}
            />
            <button type="submit" disabled={loading}>
              {loading ? 'Đang tìm...' : 'Tra cứu'}
            </button>
          </div>
        </div>
      </form>

      {result && (
        <div className="container">
          <h3>Thông tin thí sinh</h3>
          <div className="grid-2">
            <div>
              <p><strong>Họ và tên:</strong> {result.ho_ten}</p>
              <p><strong>CMND/CCCD:</strong> {result.cmnd_cccd}</p>
              <p><strong>Ngành đăng ký:</strong> {result.nganh_dang_ky}</p>
              <p><strong>Trạng thái:</strong> 
                <span style={{ 
                  color: result.trang_thai === 'Đã duyệt' ? '#28a745' : 
                         result.trang_thai === 'Không đạt' ? '#dc3545' : '#ffc107',
                  fontWeight: 'bold',
                  marginLeft: '10px'
                }}>
                  {result.trang_thai}
                </span>
              </p>
            </div>
          </div>

          <h3 style={{ marginTop: '30px' }}>Kết quả thi</h3>
          <div className="grid-2">
            <div>
              <p><strong>Điểm Toán:</strong> {result.diem_toan || 0}</p>
              <p><strong>Điểm Văn:</strong> {result.diem_van || 0}</p>
              <p><strong>Điểm Anh:</strong> {result.diem_anh || 0}</p>
              <p><strong>Điểm Lý:</strong> {result.diem_ly || 0}</p>
              <p><strong>Điểm Hóa:</strong> {result.diem_hoa || 0}</p>
            </div>
            <div>
              <p><strong>Điểm Sinh:</strong> {result.diem_sinh || 0}</p>
              <p><strong>Điểm Sử:</strong> {result.diem_su || 0}</p>
              <p><strong>Điểm Địa:</strong> {result.diem_dia || 0}</p>
              <p><strong>Điểm GDCD:</strong> {result.diem_gdcd || 0}</p>
              <p><strong>Tổng điểm:</strong> 
                <span style={{ 
                  fontSize: '1.2em', 
                  fontWeight: 'bold', 
                  color: '#667eea',
                  marginLeft: '10px'
                }}>
                  {result.tong_diem || 0}
                </span>
              </p>
            </div>
          </div>

          <div style={{ marginTop: '20px', padding: '15px', background: '#f8f9fa', borderRadius: '8px' }}>
            <p><strong>Kết quả:</strong> 
              <span style={{ 
                fontSize: '1.2em',
                fontWeight: 'bold',
                color: result.ket_qua === 'Đậu' ? '#28a745' : 
                       result.ket_qua === 'Rớt' ? '#dc3545' : '#6c757d',
                marginLeft: '10px'
              }}>
                {result.ket_qua || 'Chưa có kết quả'}
              </span>
            </p>
            {result.ghi_chu && (
              <p style={{ marginTop: '10px' }}>
                <strong>Ghi chú:</strong> {result.ghi_chu}
              </p>
            )}
            {result.ngay_cong_bo && (
              <p style={{ marginTop: '10px', color: '#666' }}>
                <small>Ngày công bố: {new Date(result.ngay_cong_bo).toLocaleString('vi-VN')}</small>
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default SearchResults

