import { useState, useEffect } from 'react'
import axios from 'axios'

function UploadDocuments() {
  const [candidates, setCandidates] = useState([])
  const [selectedCandidate, setSelectedCandidate] = useState('')
  const [documents, setDocuments] = useState([])
  const [uploadData, setUploadData] = useState({
    candidate_id: '',
    loai_tai_lieu: 'CMND/CCCD',
    file: null
  })
  const [message, setMessage] = useState({ type: '', text: '' })

  useEffect(() => {
    fetchCandidates()
  }, [])

  useEffect(() => {
    if (selectedCandidate) {
      fetchDocuments(selectedCandidate)
    }
  }, [selectedCandidate])

  const fetchCandidates = async () => {
    try {
      const response = await axios.get('/api/candidates')
      setCandidates(response.data.data)
    } catch (error) {
      setMessage({
        type: 'error',
        text: 'Lỗi khi tải danh sách thí sinh'
      })
    }
  }

  const fetchDocuments = async (candidateId) => {
    try {
      const response = await axios.get(`/api/documents/candidate/${candidateId}`)
      setDocuments(response.data.data)
    } catch (error) {
      setMessage({
        type: 'error',
        text: 'Lỗi khi tải danh sách tài liệu'
      })
    }
  }

  const handleFileChange = (e) => {
    setUploadData({
      ...uploadData,
      file: e.target.files[0]
    })
  }

  const handleUpload = async (e) => {
    e.preventDefault()
    setMessage({ type: '', text: '' })

    if (!uploadData.candidate_id || !uploadData.file) {
      setMessage({
        type: 'error',
        text: 'Vui lòng chọn thí sinh và file để upload'
      })
      return
    }

    const formData = new FormData()
    formData.append('file', uploadData.file)
    formData.append('candidate_id', uploadData.candidate_id)
    formData.append('loai_tai_lieu', uploadData.loai_tai_lieu)

    try {
      const response = await axios.post('/api/documents/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      setMessage({ type: 'success', text: response.data.message })
      setUploadData({
        candidate_id: uploadData.candidate_id,
        loai_tai_lieu: 'CMND/CCCD',
        file: null
      })
      if (uploadData.candidate_id) {
        fetchDocuments(uploadData.candidate_id)
      }
    } catch (error) {
      setMessage({
        type: 'error',
        text: error.response?.data?.message || 'Lỗi khi upload file'
      })
    }
  }

  const handleDelete = async (docId) => {
    if (!window.confirm('Bạn có chắc chắn muốn xóa tài liệu này?')) {
      return
    }

    try {
      await axios.delete(`/api/documents/${docId}`)
      setMessage({ type: 'success', text: 'Xóa tài liệu thành công' })
      if (selectedCandidate) {
        fetchDocuments(selectedCandidate)
      }
    } catch (error) {
      setMessage({
        type: 'error',
        text: error.response?.data?.message || 'Lỗi khi xóa tài liệu'
      })
    }
  }

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i]
  }

  return (
    <div>
      <h2>Upload tài liệu</h2>
      
      {message.text && (
        <div className={`alert alert-${message.type === 'success' ? 'success' : 'error'}`}>
          {message.text}
        </div>
      )}

      <form onSubmit={handleUpload}>
        <div className="grid-2">
          <div className="form-group">
            <label>Chọn thí sinh *</label>
            <select
              value={uploadData.candidate_id}
              onChange={(e) => {
                setUploadData({ ...uploadData, candidate_id: e.target.value })
                setSelectedCandidate(e.target.value)
              }}
              required
            >
              <option value="">-- Chọn thí sinh --</option>
              {candidates.map((candidate) => (
                <option key={candidate.id} value={candidate.id}>
                  {candidate.ho_ten} - {candidate.cmnd_cccd}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Loại tài liệu *</label>
            <select
              value={uploadData.loai_tai_lieu}
              onChange={(e) => setUploadData({ ...uploadData, loai_tai_lieu: e.target.value })}
              required
            >
              <option value="CMND/CCCD">CMND/CCCD</option>
              <option value="Bằng tốt nghiệp">Bằng tốt nghiệp</option>
              <option value="Học bạ">Học bạ</option>
              <option value="Ảnh thẻ">Ảnh thẻ</option>
              <option value="Giấy khám sức khỏe">Giấy khám sức khỏe</option>
              <option value="Khác">Khác</option>
            </select>
          </div>
        </div>

        <div className="form-group">
          <label>Chọn file *</label>
          <div className="file-upload">
            <input
              type="file"
              onChange={handleFileChange}
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
              required
            />
            <small>Chấp nhận: PDF, DOC, DOCX, JPG, JPEG, PNG (tối đa 5MB)</small>
          </div>
        </div>

        <button type="submit">Upload tài liệu</button>
      </form>

      {selectedCandidate && (
        <div style={{ marginTop: '30px' }}>
          <h3>Danh sách tài liệu đã upload</h3>
          {documents.length === 0 ? (
            <div className="alert alert-info">
              Chưa có tài liệu nào được upload
            </div>
          ) : (
            <div className="document-list">
              {documents.map((doc) => (
                <div key={doc.id} className="document-item">
                  <div>
                    <strong>{doc.loai_tai_lieu}</strong>
                    <br />
                    <small>{doc.ten_file} ({formatFileSize(doc.kich_thuoc)})</small>
                    <br />
                    <small style={{ color: '#666' }}>
                      Upload: {new Date(doc.ngay_upload).toLocaleString('vi-VN')}
                    </small>
                  </div>
                  <div>
                    <a 
                      href={`http://localhost:5000${doc.duong_dan}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      style={{ marginRight: '10px' }}
                    >
                      Xem
                    </a>
                    <button 
                      className="btn-danger"
                      onClick={() => handleDelete(doc.id)}
                      style={{ padding: '5px 10px', fontSize: '14px' }}
                    >
                      Xóa
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default UploadDocuments

