import { useState, useEffect } from 'react'
import axios from 'axios'

function ManageProfiles() {
  const [candidates, setCandidates] = useState([])
  const [loading, setLoading] = useState(true)
  const [editingId, setEditingId] = useState(null)
  const [editData, setEditData] = useState({})
  const [message, setMessage] = useState({ type: '', text: '' })

  useEffect(() => {
    fetchCandidates()
  }, [])

  const fetchCandidates = async () => {
    try {
      const response = await axios.get('/api/candidates')
      setCandidates(response.data.data)
    } catch (error) {
      setMessage({
        type: 'error',
        text: 'Lỗi khi tải danh sách thí sinh'
      })
    } finally {
      setLoading(false)
    }
  }

  const handleEdit = (candidate) => {
    setEditingId(candidate.id)
    setEditData({
      ho_ten: candidate.ho_ten,
      email: candidate.email,
      so_dien_thoai: candidate.so_dien_thoai,
      dia_chi: candidate.dia_chi,
      nganh_dang_ky: candidate.nganh_dang_ky,
      trang_thai: candidate.trang_thai
    })
  }

  const handleSave = async (id) => {
    try {
      await axios.put(`/api/candidates/${id}`, editData)
      setMessage({ type: 'success', text: 'Cập nhật thành công' })
      setEditingId(null)
      fetchCandidates()
    } catch (error) {
      setMessage({
        type: 'error',
        text: error.response?.data?.message || 'Lỗi khi cập nhật'
      })
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Bạn có chắc chắn muốn xóa thí sinh này?')) {
      return
    }

    try {
      await axios.delete(`/api/candidates/${id}`)
      setMessage({ type: 'success', text: 'Xóa thành công' })
      fetchCandidates()
    } catch (error) {
      setMessage({
        type: 'error',
        text: error.response?.data?.message || 'Lỗi khi xóa'
      })
    }
  }

  const getStatusColor = (status) => {
    const colors = {
      'Chờ xử lý': '#ffc107',
      'Đã duyệt': '#28a745',
      'Không đạt': '#dc3545',
      'Đã nhập học': '#17a2b8'
    }
    return colors[status] || '#6c757d'
  }

  if (loading) {
    return <div>Đang tải...</div>
  }

  return (
    <div>
      <h2>Quản lý hồ sơ thí sinh</h2>
      
      {message.text && (
        <div className={`alert alert-${message.type === 'success' ? 'success' : 'error'}`}>
          {message.text}
        </div>
      )}

      <div style={{ overflowX: 'auto' }}>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Họ tên</th>
              <th>CMND/CCCD</th>
              <th>Email</th>
              <th>Ngành đăng ký</th>
              <th>Số tài liệu</th>
              <th>Trạng thái</th>
              <th>Kết quả</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {candidates.map((candidate) => (
              <tr key={candidate.id}>
                <td>{candidate.id}</td>
                <td>
                  {editingId === candidate.id ? (
                    <input
                      type="text"
                      value={editData.ho_ten}
                      onChange={(e) => setEditData({ ...editData, ho_ten: e.target.value })}
                      style={{ width: '150px' }}
                    />
                  ) : (
                    candidate.ho_ten
                  )}
                </td>
                <td>{candidate.cmnd_cccd}</td>
                <td>
                  {editingId === candidate.id ? (
                    <input
                      type="email"
                      value={editData.email}
                      onChange={(e) => setEditData({ ...editData, email: e.target.value })}
                      style={{ width: '150px' }}
                    />
                  ) : (
                    candidate.email
                  )}
                </td>
                <td>
                  {editingId === candidate.id ? (
                    <input
                      type="text"
                      value={editData.nganh_dang_ky}
                      onChange={(e) => setEditData({ ...editData, nganh_dang_ky: e.target.value })}
                      style={{ width: '150px' }}
                    />
                  ) : (
                    candidate.nganh_dang_ky
                  )}
                </td>
                <td>{candidate.so_tai_lieu || 0}</td>
                <td>
                  {editingId === candidate.id ? (
                    <select
                      value={editData.trang_thai}
                      onChange={(e) => setEditData({ ...editData, trang_thai: e.target.value })}
                    >
                      <option value="Chờ xử lý">Chờ xử lý</option>
                      <option value="Đã duyệt">Đã duyệt</option>
                      <option value="Không đạt">Không đạt</option>
                      <option value="Đã nhập học">Đã nhập học</option>
                    </select>
                  ) : (
                    <span style={{ 
                      color: getStatusColor(candidate.trang_thai),
                      fontWeight: 'bold'
                    }}>
                      {candidate.trang_thai}
                    </span>
                  )}
                </td>
                <td>{candidate.ket_qua || 'Chưa có'}</td>
                <td>
                  {editingId === candidate.id ? (
                    <>
                      <button 
                        className="btn-success"
                        onClick={() => handleSave(candidate.id)}
                        style={{ marginRight: '5px', padding: '5px 10px', fontSize: '14px' }}
                      >
                        Lưu
                      </button>
                      <button 
                        className="btn-secondary"
                        onClick={() => setEditingId(null)}
                        style={{ padding: '5px 10px', fontSize: '14px' }}
                      >
                        Hủy
                      </button>
                    </>
                  ) : (
                    <>
                      <button 
                        onClick={() => handleEdit(candidate)}
                        style={{ marginRight: '5px', padding: '5px 10px', fontSize: '14px' }}
                      >
                        Sửa
                      </button>
                      <button 
                        className="btn-danger"
                        onClick={() => handleDelete(candidate.id)}
                        style={{ padding: '5px 10px', fontSize: '14px' }}
                      >
                        Xóa
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {candidates.length === 0 && (
        <div className="alert alert-info">
          Chưa có thí sinh nào được đăng ký
        </div>
      )}
    </div>
  )
}

export default ManageProfiles

