-- Tạo database
CREATE DATABASE IF NOT EXISTS bdu_tuyen_sinh CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE bdu_tuyen_sinh;

-- Bảng thí sinh
CREATE TABLE IF NOT EXISTS candidates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ho_ten VARCHAR(100) NOT NULL,
    ngay_sinh DATE NOT NULL,
    gioi_tinh ENUM('Nam', 'Nữ', 'Khác') NOT NULL,
    cmnd_cccd VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    so_dien_thoai VARCHAR(15) NOT NULL,
    dia_chi TEXT NOT NULL,
    nganh_dang_ky VARCHAR(100) NOT NULL,
    khoi_thi VARCHAR(50) NOT NULL,
    trang_thai ENUM('Chờ xử lý', 'Đã duyệt', 'Không đạt', 'Đã nhập học') DEFAULT 'Chờ xử lý',
    ngay_dang_ky TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_cmnd (cmnd_cccd),
    INDEX idx_email (email),
    INDEX idx_trang_thai (trang_thai)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng tài liệu
CREATE TABLE IF NOT EXISTS documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    candidate_id INT NOT NULL,
    loai_tai_lieu ENUM('CMND/CCCD', 'Bằng tốt nghiệp', 'Học bạ', 'Ảnh thẻ', 'Giấy khám sức khỏe', 'Khác') NOT NULL,
    ten_file VARCHAR(255) NOT NULL,
    duong_dan VARCHAR(500) NOT NULL,
    kich_thuoc INT NOT NULL,
    ngay_upload TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE,
    INDEX idx_candidate (candidate_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng kết quả tuyển sinh
CREATE TABLE IF NOT EXISTS results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    candidate_id INT NOT NULL UNIQUE,
    diem_toan DECIMAL(4,2) DEFAULT 0,
    diem_van DECIMAL(4,2) DEFAULT 0,
    diem_anh DECIMAL(4,2) DEFAULT 0,
    diem_ly DECIMAL(4,2) DEFAULT 0,
    diem_hoa DECIMAL(4,2) DEFAULT 0,
    diem_sinh DECIMAL(4,2) DEFAULT 0,
    diem_su DECIMAL(4,2) DEFAULT 0,
    diem_dia DECIMAL(4,2) DEFAULT 0,
    diem_gdcd DECIMAL(4,2) DEFAULT 0,
    tong_diem DECIMAL(5,2) DEFAULT 0,
    ket_qua ENUM('Đậu', 'Rớt', 'Chưa có kết quả') DEFAULT 'Chưa có kết quả',
    ghi_chu TEXT,
    ngay_cong_bo TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE,
    INDEX idx_candidate (candidate_id),
    INDEX idx_ket_qua (ket_qua)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

