import express from 'express';
import db from '../config/database.js';

const router = express.Router();

// Cập nhật kết quả tuyển sinh
router.put('/:candidate_id', async (req, res) => {
  try {
    const { candidate_id } = req.params;
    const {
      diem_toan,
      diem_van,
      diem_anh,
      diem_ly,
      diem_hoa,
      diem_sinh,
      diem_su,
      diem_dia,
      diem_gdcd,
      ket_qua,
      ghi_chu
    } = req.body;

    // Tính tổng điểm
    const tong_diem = (
      (parseFloat(diem_toan) || 0) +
      (parseFloat(diem_van) || 0) +
      (parseFloat(diem_anh) || 0) +
      (parseFloat(diem_ly) || 0) +
      (parseFloat(diem_hoa) || 0) +
      (parseFloat(diem_sinh) || 0) +
      (parseFloat(diem_su) || 0) +
      (parseFloat(diem_dia) || 0) +
      (parseFloat(diem_gdcd) || 0)
    ).toFixed(2);

    // Kiểm tra xem đã có kết quả chưa
    const [existing] = await db.execute(
      'SELECT id FROM results WHERE candidate_id = ?',
      [candidate_id]
    );

    if (existing.length === 0) {
      // Tạo mới
      await db.execute(
        `INSERT INTO results 
         (candidate_id, diem_toan, diem_van, diem_anh, diem_ly, diem_hoa, 
          diem_sinh, diem_su, diem_dia, diem_gdcd, tong_diem, ket_qua, ghi_chu, ngay_cong_bo) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          candidate_id,
          diem_toan || 0,
          diem_van || 0,
          diem_anh || 0,
          diem_ly || 0,
          diem_hoa || 0,
          diem_sinh || 0,
          diem_su || 0,
          diem_dia || 0,
          diem_gdcd || 0,
          tong_diem,
          ket_qua || 'Chưa có kết quả',
          ghi_chu || null
        ]
      );
    } else {
      // Cập nhật
      await db.execute(
        `UPDATE results SET 
         diem_toan = ?, diem_van = ?, diem_anh = ?, diem_ly = ?, diem_hoa = ?,
         diem_sinh = ?, diem_su = ?, diem_dia = ?, diem_gdcd = ?,
         tong_diem = ?, ket_qua = ?, ghi_chu = ?, ngay_cong_bo = NOW()
         WHERE candidate_id = ?`,
        [
          diem_toan || 0,
          diem_van || 0,
          diem_anh || 0,
          diem_ly || 0,
          diem_hoa || 0,
          diem_sinh || 0,
          diem_su || 0,
          diem_dia || 0,
          diem_gdcd || 0,
          tong_diem,
          ket_qua || 'Chưa có kết quả',
          ghi_chu || null,
          candidate_id
        ]
      );
    }

    res.json({
      success: true,
      message: 'Cập nhật kết quả thành công'
    });
  } catch (error) {
    console.error('Lỗi cập nhật kết quả:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Lỗi server khi cập nhật kết quả' 
    });
  }
});

// Lấy kết quả theo candidate_id
router.get('/:candidate_id', async (req, res) => {
  try {
    const { candidate_id } = req.params;
    
    const [results] = await db.execute(
      `SELECT r.*, c.ho_ten, c.cmnd_cccd, c.nganh_dang_ky
       FROM results r
       JOIN candidates c ON r.candidate_id = c.id
       WHERE r.candidate_id = ?`,
      [candidate_id]
    );

    if (results.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Chưa có kết quả' 
      });
    }

    res.json({
      success: true,
      data: results[0]
    });
  } catch (error) {
    console.error('Lỗi lấy kết quả:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Lỗi server khi lấy kết quả' 
    });
  }
});

// Tra cứu kết quả bằng CMND/CCCD
router.get('/search/cmnd/:cmnd', async (req, res) => {
  try {
    const { cmnd } = req.params;
    
    const [results] = await db.execute(
      `SELECT r.*, c.ho_ten, c.cmnd_cccd, c.nganh_dang_ky, c.trang_thai
       FROM results r
       JOIN candidates c ON r.candidate_id = c.id
       WHERE c.cmnd_cccd = ?`,
      [cmnd]
    );

    if (results.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Không tìm thấy kết quả với CMND/CCCD này' 
      });
    }

    res.json({
      success: true,
      data: results[0]
    });
  } catch (error) {
    console.error('Lỗi tra cứu kết quả:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Lỗi server khi tra cứu kết quả' 
    });
  }
});

export default router;

