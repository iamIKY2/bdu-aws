import express from 'express';
import db from '../config/database.js';

const router = express.Router();

// Đăng ký thông tin thí sinh mới
router.post('/register', async (req, res) => {
  try {
    const {
      ho_ten,
      ngay_sinh,
      gioi_tinh,
      cmnd_cccd,
      email,
      so_dien_thoai,
      dia_chi,
      nganh_dang_ky,
      khoi_thi
    } = req.body;

    // Kiểm tra dữ liệu đầu vào
    if (!ho_ten || !ngay_sinh || !gioi_tinh || !cmnd_cccd || !email || 
        !so_dien_thoai || !dia_chi || !nganh_dang_ky || !khoi_thi) {
      return res.status(400).json({ 
        success: false, 
        message: 'Vui lòng điền đầy đủ thông tin' 
      });
    }

    // Kiểm tra CMND/CCCD đã tồn tại chưa
    const [existing] = await db.execute(
      'SELECT id FROM candidates WHERE cmnd_cccd = ?',
      [cmnd_cccd]
    );

    if (existing.length > 0) {
      return res.status(400).json({ 
        success: false, 
        message: 'CMND/CCCD đã được đăng ký' 
      });
    }

    // Kiểm tra email đã tồn tại chưa
    const [existingEmail] = await db.execute(
      'SELECT id FROM candidates WHERE email = ?',
      [email]
    );

    if (existingEmail.length > 0) {
      return res.status(400).json({ 
        success: false, 
        message: 'Email đã được đăng ký' 
      });
    }

    // Thêm thí sinh mới
    const [result] = await db.execute(
      `INSERT INTO candidates 
       (ho_ten, ngay_sinh, gioi_tinh, cmnd_cccd, email, so_dien_thoai, dia_chi, nganh_dang_ky, khoi_thi) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [ho_ten, ngay_sinh, gioi_tinh, cmnd_cccd, email, so_dien_thoai, dia_chi, nganh_dang_ky, khoi_thi]
    );

    // Tạo bản ghi kết quả mặc định
    await db.execute(
      'INSERT INTO results (candidate_id) VALUES (?)',
      [result.insertId]
    );

    res.status(201).json({
      success: true,
      message: 'Đăng ký thành công',
      data: { id: result.insertId }
    });
  } catch (error) {
    console.error('Lỗi đăng ký:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Lỗi server khi đăng ký' 
    });
  }
});

// Lấy danh sách tất cả thí sinh (quản lý)
router.get('/', async (req, res) => {
  try {
    const [candidates] = await db.execute(
      `SELECT c.*, 
              COUNT(d.id) as so_tai_lieu,
              r.ket_qua, r.tong_diem
       FROM candidates c
       LEFT JOIN documents d ON c.id = d.candidate_id
       LEFT JOIN results r ON c.id = r.candidate_id
       GROUP BY c.id
       ORDER BY c.ngay_dang_ky DESC`
    );

    res.json({
      success: true,
      data: candidates
    });
  } catch (error) {
    console.error('Lỗi lấy danh sách:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Lỗi server khi lấy danh sách' 
    });
  }
});

// Lấy thông tin thí sinh theo ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const [candidates] = await db.execute(
      `SELECT c.*, 
              r.diem_toan, r.diem_van, r.diem_anh, r.diem_ly, r.diem_hoa, 
              r.diem_sinh, r.diem_su, r.diem_dia, r.diem_gdcd, 
              r.tong_diem, r.ket_qua, r.ghi_chu
       FROM candidates c
       LEFT JOIN results r ON c.id = r.candidate_id
       WHERE c.id = ?`,
      [id]
    );

    if (candidates.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Không tìm thấy thí sinh' 
      });
    }

    res.json({
      success: true,
      data: candidates[0]
    });
  } catch (error) {
    console.error('Lỗi lấy thông tin:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Lỗi server khi lấy thông tin' 
    });
  }
});

// Cập nhật thông tin thí sinh
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const {
      ho_ten,
      ngay_sinh,
      gioi_tinh,
      email,
      so_dien_thoai,
      dia_chi,
      nganh_dang_ky,
      khoi_thi,
      trang_thai
    } = req.body;

    const updateFields = [];
    const updateValues = [];

    if (ho_ten) { updateFields.push('ho_ten = ?'); updateValues.push(ho_ten); }
    if (ngay_sinh) { updateFields.push('ngay_sinh = ?'); updateValues.push(ngay_sinh); }
    if (gioi_tinh) { updateFields.push('gioi_tinh = ?'); updateValues.push(gioi_tinh); }
    if (email) { updateFields.push('email = ?'); updateValues.push(email); }
    if (so_dien_thoai) { updateFields.push('so_dien_thoai = ?'); updateValues.push(so_dien_thoai); }
    if (dia_chi) { updateFields.push('dia_chi = ?'); updateValues.push(dia_chi); }
    if (nganh_dang_ky) { updateFields.push('nganh_dang_ky = ?'); updateValues.push(nganh_dang_ky); }
    if (khoi_thi) { updateFields.push('khoi_thi = ?'); updateValues.push(khoi_thi); }
    if (trang_thai) { updateFields.push('trang_thai = ?'); updateValues.push(trang_thai); }

    if (updateFields.length === 0) {
      return res.status(400).json({ 
        success: false, 
        message: 'Không có dữ liệu để cập nhật' 
      });
    }

    updateValues.push(id);

    await db.execute(
      `UPDATE candidates SET ${updateFields.join(', ')} WHERE id = ?`,
      updateValues
    );

    res.json({
      success: true,
      message: 'Cập nhật thông tin thành công'
    });
  } catch (error) {
    console.error('Lỗi cập nhật:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Lỗi server khi cập nhật' 
    });
  }
});

// Xóa thí sinh
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    await db.execute('DELETE FROM candidates WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Xóa thí sinh thành công'
    });
  } catch (error) {
    console.error('Lỗi xóa:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Lỗi server khi xóa' 
    });
  }
});

// Tra cứu thông tin bằng CMND/CCCD
router.get('/search/cmnd/:cmnd', async (req, res) => {
  try {
    const { cmnd } = req.params;
    
    const [candidates] = await db.execute(
      `SELECT c.*, 
              r.diem_toan, r.diem_van, r.diem_anh, r.diem_ly, r.diem_hoa, 
              r.diem_sinh, r.diem_su, r.diem_dia, r.diem_gdcd, 
              r.tong_diem, r.ket_qua, r.ghi_chu, r.ngay_cong_bo
       FROM candidates c
       LEFT JOIN results r ON c.id = r.candidate_id
       WHERE c.cmnd_cccd = ?`,
      [cmnd]
    );

    if (candidates.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Không tìm thấy thông tin với CMND/CCCD này' 
      });
    }

    res.json({
      success: true,
      data: candidates[0]
    });
  } catch (error) {
    console.error('Lỗi tra cứu:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Lỗi server khi tra cứu' 
    });
  }
});

export default router;

