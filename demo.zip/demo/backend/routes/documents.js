import express from 'express';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';
import db from '../config/database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const router = express.Router();

// Tạo thư mục uploads nếu chưa có
const uploadDir = join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Cấu hình multer cho upload file
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|pdf|doc|docx/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (extname && mimetype) {
      return cb(null, true);
    } else {
      cb(new Error('Chỉ chấp nhận file: jpeg, jpg, png, pdf, doc, docx'));
    }
  }
});

// Upload tài liệu
router.post('/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ 
        success: false, 
        message: 'Vui lòng chọn file để upload' 
      });
    }

    const { candidate_id, loai_tai_lieu } = req.body;

    if (!candidate_id || !loai_tai_lieu) {
      // Xóa file đã upload nếu thiếu thông tin
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ 
        success: false, 
        message: 'Thiếu thông tin candidate_id hoặc loai_tai_lieu' 
      });
    }

    // Kiểm tra candidate có tồn tại không
    const [candidates] = await db.execute(
      'SELECT id FROM candidates WHERE id = ?',
      [candidate_id]
    );

    if (candidates.length === 0) {
      fs.unlinkSync(req.file.path);
      return res.status(404).json({ 
        success: false, 
        message: 'Không tìm thấy thí sinh' 
      });
    }

    // Lưu thông tin file vào database
    const [result] = await db.execute(
      `INSERT INTO documents (candidate_id, loai_tai_lieu, ten_file, duong_dan, kich_thuoc) 
       VALUES (?, ?, ?, ?, ?)`,
      [
        candidate_id,
        loai_tai_lieu,
        req.file.originalname,
        `/uploads/${req.file.filename}`,
        req.file.size
      ]
    );

    res.status(201).json({
      success: true,
      message: 'Upload tài liệu thành công',
      data: {
        id: result.insertId,
        ten_file: req.file.originalname,
        duong_dan: `/uploads/${req.file.filename}`,
        kich_thuoc: req.file.size
      }
    });
  } catch (error) {
    console.error('Lỗi upload:', error);
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }
    res.status(500).json({ 
      success: false, 
      message: 'Lỗi server khi upload file' 
    });
  }
});

// Lấy danh sách tài liệu của một thí sinh
router.get('/candidate/:candidate_id', async (req, res) => {
  try {
    const { candidate_id } = req.params;
    
    const [documents] = await db.execute(
      'SELECT * FROM documents WHERE candidate_id = ? ORDER BY ngay_upload DESC',
      [candidate_id]
    );

    res.json({
      success: true,
      data: documents
    });
  } catch (error) {
    console.error('Lỗi lấy danh sách tài liệu:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Lỗi server khi lấy danh sách tài liệu' 
    });
  }
});

// Xóa tài liệu
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Lấy thông tin file trước khi xóa
    const [documents] = await db.execute(
      'SELECT duong_dan FROM documents WHERE id = ?',
      [id]
    );

    if (documents.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Không tìm thấy tài liệu' 
      });
    }

    // Xóa file khỏi hệ thống
    const filePath = join(__dirname, '..', documents[0].duong_dan);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }

    // Xóa record trong database
    await db.execute('DELETE FROM documents WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Xóa tài liệu thành công'
    });
  } catch (error) {
    console.error('Lỗi xóa tài liệu:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Lỗi server khi xóa tài liệu' 
    });
  }
});

export default router;

