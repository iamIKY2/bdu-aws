import mysql from 'mysql2';
import dotenv from 'dotenv';

dotenv.config();

// Tạo pool kết nối
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'bdu_tuyen_sinh',
  port: process.env.DB_PORT || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Chuyển đổi sang Promise
const promisePool = pool.promise();

export default promisePool;

