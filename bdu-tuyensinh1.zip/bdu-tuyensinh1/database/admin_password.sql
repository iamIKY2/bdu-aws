-- Script để tạo mật khẩu admin
-- Mật khẩu mặc định: admin123
-- Hash này được tạo bằng bcrypt với cost 10
-- Để thay đổi, chạy: node -e "const bcrypt=require('bcryptjs'); bcrypt.hash('password_moi',10).then(h=>console.log(h))"

UPDATE nguoi_dung 
SET password = '$2a$10$rOzJqMQvKsFZqJZqJZqJZuJZqJZqJZqJZqJZqJZqJZqJZqJZqJZqO' 
WHERE email = 'admin@bdu.edu.vn';

