-- Tạo database
CREATE DATABASE IF NOT EXISTS bdu_tuyensinh CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bdu_tuyensinh;

-- Bảng người dùng
CREATE TABLE IF NOT EXISTS nguoi_dung (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    ho_ten VARCHAR(255) NOT NULL,
    so_dien_thoai VARCHAR(20),
    vai_tro ENUM('admin', 'thi_sinh') DEFAULT 'thi_sinh',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng ngành học
CREATE TABLE IF NOT EXISTS nganh (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ma_nganh VARCHAR(50) UNIQUE NOT NULL,
    ten_nganh VARCHAR(255) NOT NULL,
    mo_ta TEXT,
    chi_tieu INT,
    diem_chuan DECIMAL(4,2),
    thoi_gian_dao_tao VARCHAR(50),
    trang_thai ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_ma_nganh (ma_nganh)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng hồ sơ đăng ký
CREATE TABLE IF NOT EXISTS ho_so (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nguoi_dung_id INT NOT NULL,
    nganh_id INT NOT NULL,
    ho_ten VARCHAR(255) NOT NULL,
    ngay_sinh DATE NOT NULL,
    gioi_tinh ENUM('Nam', 'Nữ', 'Khác'),
    cmnd_cccd VARCHAR(20) NOT NULL,
    dan_toc VARCHAR(50),
    ton_giao VARCHAR(50),
    dia_chi TEXT NOT NULL,
    so_dien_thoai VARCHAR(20),
    email VARCHAR(255),
    truong_thpt VARCHAR(255),
    nam_tot_nghiep INT,
    diem_tong_ket DECIMAL(4,2),
    nganh_uu_tien_1 INT,
    nganh_uu_tien_2 INT,
    anh_the VARCHAR(255),
    cmnd_file VARCHAR(255),
    hoc_ba_file VARCHAR(255),
    trang_thai ENUM('cho_duyet', 'da_duyet', 'tu_choi', 'trung_tuyen', 'khong_trung_tuyen') DEFAULT 'cho_duyet',
    ghi_chu TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (nguoi_dung_id) REFERENCES nguoi_dung(id) ON DELETE CASCADE,
    FOREIGN KEY (nganh_id) REFERENCES nganh(id) ON DELETE RESTRICT,
    FOREIGN KEY (nganh_uu_tien_1) REFERENCES nganh(id) ON DELETE SET NULL,
    FOREIGN KEY (nganh_uu_tien_2) REFERENCES nganh(id) ON DELETE SET NULL,
    INDEX idx_nguoi_dung (nguoi_dung_id),
    INDEX idx_nganh (nganh_id),
    INDEX idx_trang_thai (trang_thai)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Thêm dữ liệu mẫu cho ngành học
INSERT INTO nganh (ma_nganh, ten_nganh, mo_ta, chi_tieu, diem_chuan, thoi_gian_dao_tao) VALUES
('CNTT', 'Công nghệ thông tin', 'Ngành đào tạo về công nghệ thông tin, lập trình, hệ thống máy tính', 100, 18.0, '4 năm'),
('KT', 'Kế toán', 'Ngành đào tạo về kế toán, kiểm toán, tài chính', 80, 17.5, '4 năm'),
('QTKD', 'Quản trị kinh doanh', 'Ngành đào tạo về quản lý, kinh doanh, marketing', 120, 17.0, '4 năm'),
('NN', 'Ngôn ngữ Anh', 'Ngành đào tạo về ngôn ngữ và văn hóa Anh', 60, 16.5, '4 năm'),
('DL', 'Du lịch', 'Ngành đào tạo về quản trị du lịch và lữ hành', 70, 16.0, '4 năm');

-- Tạo tài khoản admin mặc định (mật khẩu: admin123)
-- Lưu ý: Mật khẩu được lưu dạng plain text (không mã hóa)
INSERT INTO nguoi_dung (email, password, ho_ten, so_dien_thoai, vai_tro) VALUES
('admin@bdu.edu.vn', 'admin123', 'Quản trị viên', '0123456789', 'admin');

