# Hệ thống Tuyển sinh BDU

Hệ thống tuyển sinh trực tuyến cho trường Đại học BDU, bao gồm Frontend (React), Backend (Node.js + Express) và Database (MySQL).

## Tính năng

- ✅ Đăng ký/Đăng nhập tài khoản
- ✅ Xem danh sách ngành học
- ✅ Đăng ký hồ sơ tuyển sinh
- ✅ Upload giấy tờ (ảnh thẻ, CMND, học bạ)
- ✅ Xem danh sách hồ sơ đã nộp
- ✅ Theo dõi trạng thái hồ sơ
- ✅ Giao diện responsive, thân thiện người dùng

## Cấu trúc dự án

```
bdu-tuyensinh/
├── backend/          # Backend API (Node.js + Express)
│   ├── config/       # Cấu hình database
│   ├── middleware/   # Middleware xác thực
│   ├── routes/       # API routes
│   └── uploads/      # Thư mục lưu file upload
├── frontend/         # Frontend (React + Vite)
│   ├── src/
│   │   ├── components/   # Components
│   │   ├── pages/        # Pages
│   │   └── context/      # Context API
├── database/         # SQL scripts
│   └── schema.sql    # Database schema
└── README.md
```

## Yêu cầu hệ thống

- Node.js (v16 trở lên)
- MySQL (5.7 trở lên) hoặc MariaDB
- npm hoặc yarn

## Hướng dẫn cài đặt

### 1. Cài đặt Database

1. Mở MySQL/MariaDB (sử dụng phpMyAdmin hoặc command line)
2. Import file `database/schema.sql` để tạo database và các bảng cần thiết
3. Database sẽ được tạo với tên `bdu_tuyensinh`

**Tài khoản admin mặc định:**
- Email: `admin@bdu.edu.vn`
- Mật khẩu: `admin123`

### 2. Cài đặt Backend

```bash
# Di chuyển vào thư mục backend
cd backend

# Cài đặt dependencies
npm install

# Tạo file .env từ .env.example
copy .env.example .env

# Chỉnh sửa file .env với thông tin database của bạn
# PORT=3000
# DB_HOST=localhost
# DB_USER=root
# DB_PASSWORD=your_password
# DB_NAME=bdu_tuyensinh
# JWT_SECRET=your-secret-key-change-this-in-production
# UPLOAD_PATH=./uploads

# Tạo thư mục uploads
mkdir uploads

# Chạy server (development)
npm run dev

# Hoặc chạy production
npm start
```

Backend sẽ chạy tại: `http://localhost:3000`

### 3. Cài đặt Frontend

Mở terminal mới:

```bash
# Di chuyển vào thư mục frontend
cd frontend

# Cài đặt dependencies
npm install

# Chạy development server
npm run dev
```

Frontend sẽ chạy tại: `http://localhost:5173`

## Sử dụng

1. Truy cập `http://localhost:5173` trong trình duyệt
2. Đăng ký tài khoản mới hoặc đăng nhập
3. Xem danh sách ngành học
4. Đăng ký hồ sơ tuyển sinh
5. Xem danh sách hồ sơ đã nộp

## API Endpoints

### Authentication
- `POST /api/auth/register` - Đăng ký tài khoản
- `POST /api/auth/login` - Đăng nhập

### Ngành học
- `GET /api/nganh` - Lấy danh sách ngành học
- `GET /api/nganh/:id` - Lấy chi tiết ngành học

### Hồ sơ
- `POST /api/ho-so` - Tạo hồ sơ đăng ký (yêu cầu đăng nhập)
- `GET /api/ho-so/my` - Lấy danh sách hồ sơ của người dùng (yêu cầu đăng nhập)
- `GET /api/ho-so/:id` - Lấy chi tiết hồ sơ (yêu cầu đăng nhập)

### Người dùng
- `GET /api/nguoi-dung/me` - Lấy thông tin người dùng hiện tại (yêu cầu đăng nhập)
- `PUT /api/nguoi-dung/me` - Cập nhật thông tin người dùng (yêu cầu đăng nhập)

## Công nghệ sử dụng

### Backend
- Node.js
- Express.js
- MySQL2
- JWT (JSON Web Token)
- Bcryptjs (mã hóa mật khẩu)
- Multer (upload file)
- CORS

### Frontend
- React 18
- React Router DOM
- Axios
- Vite
- CSS3

### Database
- MySQL/MariaDB

## Lưu ý

- Mật khẩu admin mặc định nên được thay đổi sau khi cài đặt
- JWT_SECRET trong file .env nên được thay đổi trong môi trường production
- Đảm bảo thư mục `backend/uploads` có quyền ghi
- Kích thước file upload tối đa: 5MB
- Định dạng file được chấp nhận: JPEG, JPG, PNG, PDF

## Phát triển thêm

Một số tính năng có thể bổ sung:
- Quản trị viên: Duyệt/từ chối hồ sơ
- Tra cứu kết quả tuyển sinh
- Gửi email thông báo
- Export danh sách hồ sơ
- Thống kê số liệu tuyển sinh

## License

MIT

