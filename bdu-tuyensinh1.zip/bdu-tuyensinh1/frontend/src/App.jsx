import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import Navbar from './components/Navbar'
import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import DangKyHoSo from './pages/DangKyHoSo'
import DanhSachHoSo from './pages/DanhSachHoSo'
import { AuthProvider, useAuth } from './context/AuthContext'
import './App.css'

// Protected Route component
const ProtectedRoute = ({ children }) => {
  const { user } = useAuth()
  return user ? children : <Navigate to="/login" />
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="App">
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route 
              path="/dashboard" 
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/dang-ky-ho-so" 
              element={
                <ProtectedRoute>
                  <DangKyHoSo />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/danh-sach-ho-so" 
              element={
                <ProtectedRoute>
                  <DanhSachHoSo />
                </ProtectedRoute>
              } 
            />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  )
}

export default App

