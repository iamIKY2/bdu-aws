import React from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import './Navbar.css'

const Navbar = () => {
  const { user, logout } = useAuth()

  return (
    <nav className="navbar">
      <div className="container">
        <div className="nav-content">
          <Link to="/" className="nav-logo">
            <h2>BDU Tuyển sinh</h2>
          </Link>
          <div className="nav-links">
            <Link to="/">Trang chủ</Link>
            {user ? (
              <>
                <Link to="/dashboard">Dashboard</Link>
                <Link to="/dang-ky-ho-so">Đăng ký hồ sơ</Link>
                <Link to="/danh-sach-ho-so">Hồ sơ của tôi</Link>
                <span className="user-info">Xin chào, {user.hoTen}</span>
                <button onClick={logout} className="btn btn-secondary">Đăng xuất</button>
              </>
            ) : (
              <>
                <Link to="/login">Đăng nhập</Link>
                <Link to="/register">Đăng ký</Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navbar

