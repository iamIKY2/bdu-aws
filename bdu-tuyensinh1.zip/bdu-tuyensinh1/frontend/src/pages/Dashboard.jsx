import React from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import './Dashboard.css'

const Dashboard = () => {
  const { user } = useAuth()

  return (
    <div className="content">
      <div className="container">
        <div className="dashboard-header">
          <h1>Dashboard</h1>
          <p>Xin chào, <strong>{user?.hoTen}</strong></p>
        </div>

        <div className="dashboard-grid">
          <Link to="/dang-ky-ho-so" className="dashboard-card card">
            <div className="card-icon">📝</div>
            <h3>Đăng ký hồ sơ</h3>
            <p>Nộp hồ sơ tuyển sinh mới</p>
          </Link>

          <Link to="/danh-sach-ho-so" className="dashboard-card card">
            <div className="card-icon">📋</div>
            <h3>Hồ sơ của tôi</h3>
            <p>Xem danh sách hồ sơ đã nộp</p>
          </Link>

          <div className="dashboard-card card">
            <div className="card-icon">ℹ️</div>
            <h3>Thông tin cá nhân</h3>
            <p>Email: {user?.email}</p>
            <p>Số điện thoại: {user?.soDienThoai || 'Chưa cập nhật'}</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard

