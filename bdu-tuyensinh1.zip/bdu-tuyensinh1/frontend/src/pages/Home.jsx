import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import './Home.css'

const Home = () => {
  const [nganh, setNganh] = useState([])

  useEffect(() => {
    // Lấy danh sách ngành học
    axios.get('/api/nganh')
      .then(response => {
        setNganh(response.data)
      })
      .catch(error => {
        console.error('Lỗi lấy danh sách ngành:', error)
      })
  }, [])

  return (
    <div className="content">
      <div className="hero">
        <div className="container">
          <h1>Hệ thống Tuyển sinh BDU</h1>
          <p>Đăng ký tuyển sinh trực tuyến - Nhanh chóng, Tiện lợi, An toàn</p>
          <div className="hero-buttons">
            <Link to="/register" className="btn btn-primary">Đăng ký tài khoản</Link>
            <Link to="/login" className="btn btn-secondary">Đăng nhập</Link>
          </div>
        </div>
      </div>

      <div className="container">
        <section className="nganh-section">
          <h2>Các ngành đào tạo</h2>
          <div className="nganh-grid">
            {nganh.map(ng => (
              <div key={ng.id} className="nganh-card card">
                <h3>{ng.ten_nganh}</h3>
                <p className="ma-nganh">Mã ngành: {ng.ma_nganh}</p>
                {ng.mo_ta && <p className="mo-ta">{ng.mo_ta}</p>}
                <div className="nganh-info">
                  {ng.chi_tieu && <span>Chỉ tiêu: {ng.chi_tieu}</span>}
                  {ng.diem_chuan && <span>Điểm chuẩn: {ng.diem_chuan}</span>}
                  {ng.thoi_gian_dao_tao && <span>Thời gian: {ng.thoi_gian_dao_tao}</span>}
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="info-section">
          <h2>Hướng dẫn đăng ký</h2>
          <div className="steps">
            <div className="step">
              <div className="step-number">1</div>
              <h3>Đăng ký tài khoản</h3>
              <p>Tạo tài khoản với email và mật khẩu của bạn</p>
            </div>
            <div className="step">
              <div className="step-number">2</div>
              <h3>Đăng nhập</h3>
              <p>Đăng nhập vào hệ thống bằng tài khoản đã tạo</p>
            </div>
            <div className="step">
              <div className="step-number">3</div>
              <h3>Nộp hồ sơ</h3>
              <p>Điền thông tin và upload các giấy tờ cần thiết</p>
            </div>
            <div className="step">
              <div className="step-number">4</div>
              <h3>Theo dõi kết quả</h3>
              <p>Kiểm tra trạng thái hồ sơ và kết quả tuyển sinh</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

export default Home

