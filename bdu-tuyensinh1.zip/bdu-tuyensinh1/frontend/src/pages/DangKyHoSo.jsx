import React, { useState, useEffect } from 'react'
import axios from 'axios'
import './DangKyHoSo.css'

const DangKyHoSo = () => {
  const [nganh, setNganh] = useState([])
  const [formData, setFormData] = useState({
    nganhId: '',
    hoTen: '',
    ngaySinh: '',
    gioiTinh: 'Nam',
    cmndCccd: '',
    danToc: '',
    tonGiao: '',
    diaChi: '',
    soDienThoai: '',
    email: '',
    truongThpt: '',
    namTotNghiep: '',
    diemTongKet: '',
    nganhUuTien1: '',
    nganhUuTien2: ''
  })
  const [files, setFiles] = useState({
    anhThe: null,
    cmnd: null,
    hocBa: null
  })
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    // Lấy danh sách ngành học
    axios.get('/api/nganh')
      .then(response => {
        setNganh(response.data)
      })
      .catch(error => {
        console.error('Lỗi lấy danh sách ngành:', error)
      })
  }, [])

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleFileChange = (e) => {
    setFiles({
      ...files,
      [e.target.name]: e.target.files[0]
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSuccess('')
    setLoading(true)

    try {
      const formDataToSend = new FormData()
      
      // Thêm tất cả các trường form
      Object.keys(formData).forEach(key => {
        if (formData[key]) {
          formDataToSend.append(key, formData[key])
        }
      })

      // Thêm các file
      if (files.anhThe) formDataToSend.append('anhThe', files.anhThe)
      if (files.cmnd) formDataToSend.append('cmnd', files.cmnd)
      if (files.hocBa) formDataToSend.append('hocBa', files.hocBa)

      const response = await axios.post('/api/ho-so', formDataToSend, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })

      setSuccess('Nộp hồ sơ thành công!')
      // Reset form
      setFormData({
        nganhId: '',
        hoTen: '',
        ngaySinh: '',
        gioiTinh: 'Nam',
        cmndCccd: '',
        danToc: '',
        tonGiao: '',
        diaChi: '',
        soDienThoai: '',
        email: '',
        truongThpt: '',
        namTotNghiep: '',
        diemTongKet: '',
        nganhUuTien1: '',
        nganhUuTien2: ''
      })
      setFiles({
        anhThe: null,
        cmnd: null,
        hocBa: null
      })
    } catch (error) {
      setError(error.response?.data?.message || 'Có lỗi xảy ra khi nộp hồ sơ')
    }
    
    setLoading(false)
  }

  return (
    <div className="content">
      <div className="container">
        <div className="page-header">
          <h1>Đăng ký hồ sơ tuyển sinh</h1>
        </div>

        <form onSubmit={handleSubmit} className="ho-so-form">
          {error && <div className="error">{error}</div>}
          {success && <div className="success">{success}</div>}

          <div className="form-section">
            <h2>Thông tin ngành học</h2>
            <div className="form-group">
              <label>Ngành đăng ký <span className="required">*</span></label>
              <select
                name="nganhId"
                value={formData.nganhId}
                onChange={handleChange}
                required
              >
                <option value="">Chọn ngành học</option>
                {nganh.map(ng => (
                  <option key={ng.id} value={ng.id}>
                    {ng.ten_nganh} ({ng.ma_nganh})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="form-section">
            <h2>Thông tin cá nhân</h2>
            <div className="form-row">
              <div className="form-group">
                <label>Họ và tên <span className="required">*</span></label>
                <input
                  type="text"
                  name="hoTen"
                  value={formData.hoTen}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label>Ngày sinh <span className="required">*</span></label>
                <input
                  type="date"
                  name="ngaySinh"
                  value={formData.ngaySinh}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label>Giới tính</label>
                <select
                  name="gioiTinh"
                  value={formData.gioiTinh}
                  onChange={handleChange}
                >
                  <option value="Nam">Nam</option>
                  <option value="Nữ">Nữ</option>
                  <option value="Khác">Khác</option>
                </select>
              </div>
              <div className="form-group">
                <label>CMND/CCCD <span className="required">*</span></label>
                <input
                  type="text"
                  name="cmndCccd"
                  value={formData.cmndCccd}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label>Dân tộc</label>
                <input
                  type="text"
                  name="danToc"
                  value={formData.danToc}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <label>Tôn giáo</label>
                <input
                  type="text"
                  name="tonGiao"
                  value={formData.tonGiao}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="form-group">
              <label>Địa chỉ <span className="required">*</span></label>
              <textarea
                name="diaChi"
                value={formData.diaChi}
                onChange={handleChange}
                required
                rows="3"
              />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label>Số điện thoại</label>
                <input
                  type="tel"
                  name="soDienThoai"
                  value={formData.soDienThoai}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <label>Email</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>

          <div className="form-section">
            <h2>Thông tin học tập</h2>
            <div className="form-row">
              <div className="form-group">
                <label>Trường THPT</label>
                <input
                  type="text"
                  name="truongThpt"
                  value={formData.truongThpt}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <label>Năm tốt nghiệp</label>
                <input
                  type="number"
                  name="namTotNghiep"
                  value={formData.namTotNghiep}
                  onChange={handleChange}
                  min="2000"
                  max="2030"
                />
              </div>
            </div>
            <div className="form-group">
              <label>Điểm tổng kết</label>
              <input
                type="number"
                name="diemTongKet"
                value={formData.diemTongKet}
                onChange={handleChange}
                step="0.01"
                min="0"
                max="30"
              />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label>Ngành ưu tiên 1</label>
                <select
                  name="nganhUuTien1"
                  value={formData.nganhUuTien1}
                  onChange={handleChange}
                >
                  <option value="">Chọn ngành</option>
                  {nganh.map(ng => (
                    <option key={ng.id} value={ng.id}>
                      {ng.ten_nganh}
                    </option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label>Ngành ưu tiên 2</label>
                <select
                  name="nganhUuTien2"
                  value={formData.nganhUuTien2}
                  onChange={handleChange}
                >
                  <option value="">Chọn ngành</option>
                  {nganh.map(ng => (
                    <option key={ng.id} value={ng.id}>
                      {ng.ten_nganh}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="form-section">
            <h2>Giấy tờ đính kèm</h2>
            <div className="form-row">
              <div className="form-group">
                <label>Ảnh thẻ (JPEG/PNG, tối đa 5MB)</label>
                <input
                  type="file"
                  name="anhThe"
                  onChange={handleFileChange}
                  accept="image/jpeg,image/jpg,image/png"
                />
              </div>
              <div className="form-group">
                <label>CMND/CCCD (PDF/JPEG/PNG, tối đa 5MB)</label>
                <input
                  type="file"
                  name="cmnd"
                  onChange={handleFileChange}
                  accept=".pdf,image/jpeg,image/jpg,image/png"
                />
              </div>
            </div>
            <div className="form-group">
              <label>Học bạ (PDF/JPEG/PNG, tối đa 5MB)</label>
              <input
                type="file"
                name="hocBa"
                onChange={handleFileChange}
                accept=".pdf,image/jpeg,image/jpg,image/png"
              />
            </div>
          </div>

          <div className="form-actions">
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Đang xử lý...' : 'Nộp hồ sơ'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default DangKyHoSo

