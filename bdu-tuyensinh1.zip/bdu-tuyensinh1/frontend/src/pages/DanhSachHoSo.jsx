import React, { useState, useEffect } from 'react'
import axios from 'axios'
import './DanhSachHoSo.css'

const DanhSachHoSo = () => {
  const [hoSo, setHoSo] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedHoSo, setSelectedHoSo] = useState(null)

  useEffect(() => {
    loadHoSo()
  }, [])

  const loadHoSo = async () => {
    try {
      const response = await axios.get('/api/ho-so/my')
      setHoSo(response.data)
    } catch (error) {
      console.error('Lỗi lấy danh sách hồ sơ:', error)
    } finally {
      setLoading(false)
    }
  }

  const getTrangThaiBadge = (trangThai) => {
    const badges = {
      cho_duyet: { text: 'Chờ duyệt', class: 'badge-warning' },
      da_duyet: { text: 'Đã duyệt', class: 'badge-info' },
      tu_choi: { text: 'Từ chối', class: 'badge-danger' },
      trung_tuyen: { text: 'Trúng tuyển', class: 'badge-success' },
      khong_trung_tuyen: { text: 'Không trúng tuyển', class: 'badge-secondary' }
    }
    return badges[trangThai] || { text: trangThai, class: 'badge-secondary' }
  }

  const formatDate = (dateString) => {
    if (!dateString) return ''
    const date = new Date(dateString)
    return date.toLocaleDateString('vi-VN')
  }

  if (loading) {
    return (
      <div className="content">
        <div className="container">
          <p>Đang tải...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="content">
      <div className="container">
        <div className="page-header">
          <h1>Danh sách hồ sơ của tôi</h1>
        </div>

        {hoSo.length === 0 ? (
          <div className="empty-state card">
            <p>Bạn chưa có hồ sơ nào. <a href="/dang-ky-ho-so">Đăng ký hồ sơ ngay</a></p>
          </div>
        ) : (
          <div className="ho-so-list">
            {hoSo.map(hs => {
              const badge = getTrangThaiBadge(hs.trang_thai)
              return (
                <div key={hs.id} className="ho-so-item card">
                  <div className="ho-so-header">
                    <div>
                      <h3>{hs.ten_nganh}</h3>
                      <p className="ma-nganh">Mã ngành: {hs.ma_nganh}</p>
                    </div>
                    <span className={`badge ${badge.class}`}>{badge.text}</span>
                  </div>
                  
                  <div className="ho-so-info">
                    <p><strong>Họ tên:</strong> {hs.ho_ten}</p>
                    <p><strong>Ngày sinh:</strong> {formatDate(hs.ngay_sinh)}</p>
                    <p><strong>Ngày nộp:</strong> {formatDate(hs.created_at)}</p>
                    {hs.ghi_chu && (
                      <p><strong>Ghi chú:</strong> {hs.ghi_chu}</p>
                    )}
                  </div>

                  <button
                    onClick={() => setSelectedHoSo(selectedHoSo === hs.id ? null : hs.id)}
                    className="btn btn-secondary"
                  >
                    {selectedHoSo === hs.id ? 'Ẩn chi tiết' : 'Xem chi tiết'}
                  </button>

                  {selectedHoSo === hs.id && (
                    <div className="ho-so-detail">
                      <h4>Chi tiết hồ sơ</h4>
                      <div className="detail-grid">
                        <div>
                          <p><strong>Giới tính:</strong> {hs.gioi_tinh || 'N/A'}</p>
                          <p><strong>CMND/CCCD:</strong> {hs.cmnd_cccd}</p>
                          <p><strong>Dân tộc:</strong> {hs.dan_toc || 'N/A'}</p>
                          <p><strong>Tôn giáo:</strong> {hs.ton_giao || 'N/A'}</p>
                        </div>
                        <div>
                          <p><strong>Địa chỉ:</strong> {hs.dia_chi}</p>
                          <p><strong>Số điện thoại:</strong> {hs.so_dien_thoai || 'N/A'}</p>
                          <p><strong>Email:</strong> {hs.email || 'N/A'}</p>
                        </div>
                        <div>
                          <p><strong>Trường THPT:</strong> {hs.truong_thpt || 'N/A'}</p>
                          <p><strong>Năm tốt nghiệp:</strong> {hs.nam_tot_nghiep || 'N/A'}</p>
                          <p><strong>Điểm tổng kết:</strong> {hs.diem_tong_ket || 'N/A'}</p>
                        </div>
                      </div>
                      {hs.anh_the && (
                        <p><strong>Ảnh thẻ:</strong> Đã tải lên</p>
                      )}
                      {hs.cmnd_file && (
                        <p><strong>CMND/CCCD:</strong> Đã tải lên</p>
                      )}
                      {hs.hoc_ba_file && (
                        <p><strong>Học bạ:</strong> Đã tải lên</p>
                      )}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

export default DanhSachHoSo

