# Hướng dẫn cài đặt nhanh - Hệ thống Tuyển sinh BDU

## Bước 1: Cài đặt Database

1. Mở phpMyAdmin hoặc MySQL command line
2. Import file `database/schema.sql` 
   - Trong phpMyAdmin: Chọn tab "Import", chọn file `schema.sql`, nhấn "Go"
   - Command line: `mysql -u root -p < database/schema.sql`

3. Database `bdu_tuyensinh` sẽ được tạo tự động cùng với các bảng và dữ liệu mẫu

**Tài khoản admin:**
- Email: `admin@bdu.edu.vn`
- Mật khẩu: `admin123`

## Bước 2: Cài đặt Backend

```bash
cd backend
npm install
```

Tạo file `.env` (copy từ `.env.example` và chỉnh sửa):

```env
PORT=3000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=
DB_NAME=bdu_tuyensinh
JWT_SECRET=your-secret-key-change-this-in-production
UPLOAD_PATH=./uploads
```

**Lưu ý:** Nếu MySQL của bạn có mật khẩu, điền vào `DB_PASSWORD`. Nếu không có mật khẩu, để trống.

Chạy backend:

```bash
npm run dev
```

Backend sẽ chạy tại: `http://localhost:3000`

## Bước 3: Cài đặt Frontend

Mở terminal mới:

```bash
cd frontend
npm install
npm run dev
```

Frontend sẽ chạy tại: `http://localhost:5173`

## Bước 4: Sử dụng

1. Mở trình duyệt, truy cập: `http://localhost:5173`
2. Đăng ký tài khoản mới hoặc đăng nhập với tài khoản admin
3. Bắt đầu sử dụng hệ thống!

## Xử lý lỗi thường gặp

### Lỗi kết nối database
- Kiểm tra MySQL/MariaDB đã chạy chưa
- Kiểm tra thông tin trong file `.env` đã đúng chưa
- Kiểm tra database `bdu_tuyensinh` đã được tạo chưa

### Lỗi port đã được sử dụng
- Đổi PORT trong file `.env` của backend
- Hoặc đổi port trong `vite.config.js` của frontend

### Lỗi upload file
- Đảm bảo thư mục `backend/uploads` đã được tạo
- Kiểm tra quyền ghi file trong thư mục đó

## Cấu trúc Database

- `nguoi_dung`: Bảng người dùng
- `nganh`: Bảng ngành học
- `ho_so`: Bảng hồ sơ đăng ký tuyển sinh

## Thay đổi mật khẩu admin

Nếu muốn thay đổi mật khẩu admin, chạy:

```bash
cd backend
node scripts/generatePassword.js <mật_khẩu_mới>
```

Sau đó copy hash được tạo ra và update vào database.

