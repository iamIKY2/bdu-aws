import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// Import routes
import nguoiDungRoutes from './routes/nguoiDung.js';
import nganhRoutes from './routes/nganh.js';
import hoSoRoutes from './routes/hoSo.js';
import authRoutes from './routes/auth.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Phục vụ file tĩnh cho uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/nguoi-dung', nguoiDungRoutes);
app.use('/api/nganh', nganhRoutes);
app.use('/api/ho-so', hoSoRoutes);

// Route mặc định
app.get('/api', (req, res) => {
  res.json({ message: 'API Hệ thống Tuyển sinh BDU' });
});

// Khởi động server
app.listen(PORT, () => {
  console.log(`Server đang chạy tại http://localhost:${PORT}`);
});

