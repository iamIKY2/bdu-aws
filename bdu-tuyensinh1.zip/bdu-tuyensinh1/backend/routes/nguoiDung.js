import express from 'express';
import pool from '../config/database.js';
import { authenticate, isAdmin } from '../middleware/auth.js';

const router = express.Router();

// Lấy danh sách người dùng (chỉ admin)
router.get('/', authenticate, isAdmin, async (req, res) => {
  try {
    const [users] = await pool.execute(
      'SELECT id, email, ho_ten, so_dien_thoai, vai_tro, created_at FROM nguoi_dung ORDER BY created_at DESC'
    );
    res.json(users);
  } catch (error) {
    console.error('Lỗi lấy danh sách người dùng:', error);
    res.status(500).json({ message: 'Lỗi server' });
  }
});

// Lấy thông tin người dùng hiện tại
router.get('/me', authenticate, async (req, res) => {
  try {
    const [users] = await pool.execute(
      'SELECT id, email, ho_ten, so_dien_thoai, vai_tro, created_at FROM nguoi_dung WHERE id = ?',
      [req.user.userId]
    );

    if (users.length === 0) {
      return res.status(404).json({ message: 'Không tìm thấy người dùng' });
    }

    res.json(users[0]);
  } catch (error) {
    console.error('Lỗi lấy thông tin người dùng:', error);
    res.status(500).json({ message: 'Lỗi server' });
  }
});

// Cập nhật thông tin người dùng
router.put('/me', authenticate, async (req, res) => {
  try {
    const { hoTen, soDienThoai } = req.body;

    await pool.execute(
      'UPDATE nguoi_dung SET ho_ten = ?, so_dien_thoai = ? WHERE id = ?',
      [hoTen, soDienThoai, req.user.userId]
    );

    res.json({ message: 'Cập nhật thông tin thành công' });
  } catch (error) {
    console.error('Lỗi cập nhật thông tin:', error);
    res.status(500).json({ message: 'Lỗi server' });
  }
});

export default router;

