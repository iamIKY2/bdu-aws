import express from 'express';
import pool from '../config/database.js';

const router = express.Router();

// Lấy danh sách tất cả ngành học
router.get('/', async (req, res) => {
  try {
    const [nganh] = await pool.execute(
      'SELECT * FROM nganh WHERE trang_thai = "active" ORDER BY ten_nganh'
    );
    res.json(nganh);
  } catch (error) {
    console.error('Lỗi lấy danh sách ngành:', error);
    res.status(500).json({ message: 'Lỗi server' });
  }
});

// Lấy chi tiết một ngành học
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const [nganh] = await pool.execute(
      'SELECT * FROM nganh WHERE id = ? AND trang_thai = "active"',
      [id]
    );

    if (nganh.length === 0) {
      return res.status(404).json({ message: 'Không tìm thấy ngành học' });
    }

    res.json(nganh[0]);
  } catch (error) {
    console.error('Lỗi lấy chi tiết ngành:', error);
    res.status(500).json({ message: 'Lỗi server' });
  }
});

// Tạo ngành học mới (chỉ admin - cần thêm middleware)
router.post('/', async (req, res) => {
  try {
    const { tenNganh, maNganh, moTa, chiTieu, diemChuan, thoiGianDaoTao } = req.body;

    if (!tenNganh || !maNganh) {
      return res.status(400).json({ message: 'Vui lòng điền đầy đủ thông tin' });
    }

    const [result] = await pool.execute(
      'INSERT INTO nganh (ten_nganh, ma_nganh, mo_ta, chi_tieu, diem_chuan, thoi_gian_dao_tao) VALUES (?, ?, ?, ?, ?, ?)',
      [tenNganh, maNganh, moTa || null, chiTieu || null, diemChuan || null, thoiGianDaoTao || null]
    );

    res.status(201).json({ message: 'Tạo ngành học thành công', id: result.insertId });
  } catch (error) {
    console.error('Lỗi tạo ngành học:', error);
    res.status(500).json({ message: 'Lỗi server' });
  }
});

export default router;

