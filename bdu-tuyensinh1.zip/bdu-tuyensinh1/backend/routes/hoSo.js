import express from 'express';
import pool from '../config/database.js';
import { authenticate } from '../middleware/auth.js';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = express.Router();

// Cấu hình multer cho upload file
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../uploads'));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // Giới hạn 5MB
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|pdf/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (extname && mimetype) {
      return cb(null, true);
    } else {
      cb(new Error('Chỉ chấp nhận file ảnh (JPEG, JPG, PNG) hoặc PDF'));
    }
  }
});

// Tạo hồ sơ đăng ký
router.post('/', authenticate, upload.fields([
  { name: 'anhThe', maxCount: 1 },
  { name: 'cmnd', maxCount: 1 },
  { name: 'hocBa', maxCount: 1 }
]), async (req, res) => {
  try {
    const userId = req.user.userId;
    const {
      nganhId,
      hoTen,
      ngaySinh,
      gioiTinh,
      cmndCccd,
      danToc,
      tonGiao,
      diaChi,
      soDienThoai,
      email,
      truongThpt,
      namTotNghiep,
      diemTongKet,
      nganhUuTien1,
      nganhUuTien2
    } = req.body;

    // Kiểm tra dữ liệu bắt buộc
    if (!nganhId || !hoTen || !ngaySinh || !cmndCccd || !diaChi) {
      return res.status(400).json({ message: 'Vui lòng điền đầy đủ thông tin bắt buộc' });
    }

    // Lấy đường dẫn file đã upload
    const anhThe = req.files.anhThe ? req.files.anhThe[0].filename : null;
    const cmnd = req.files.cmnd ? req.files.cmnd[0].filename : null;
    const hocBa = req.files.hocBa ? req.files.hocBa[0].filename : null;

    // Tạo hồ sơ
    const [result] = await pool.execute(
      `INSERT INTO ho_so (
        nguoi_dung_id, nganh_id, ho_ten, ngay_sinh, gioi_tinh, cmnd_cccd,
        dan_toc, ton_giao, dia_chi, so_dien_thoai, email, truong_thpt,
        nam_tot_nghiep, diem_tong_ket, nganh_uu_tien_1, nganh_uu_tien_2,
        anh_the, cmnd_file, hoc_ba_file, trang_thai
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        userId, nganhId, hoTen, ngaySinh, gioiTinh || null, cmndCccd,
        danToc || null, tonGiao || null, diaChi, soDienThoai || null, email || null,
        truongThpt || null, namTotNghiep || null, diemTongKet || null,
        nganhUuTien1 || null, nganhUuTien2 || null,
        anhThe, cmnd, hocBa, 'cho_duyet'
      ]
    );

    res.status(201).json({
      message: 'Nộp hồ sơ thành công',
      hoSoId: result.insertId
    });
  } catch (error) {
    console.error('Lỗi tạo hồ sơ:', error);
    res.status(500).json({ message: 'Lỗi server khi tạo hồ sơ' });
  }
});

// Lấy danh sách hồ sơ của người dùng hiện tại
router.get('/my', authenticate, async (req, res) => {
  try {
    const [hoSo] = await pool.execute(
      `SELECT h.*, n.ten_nganh, n.ma_nganh 
       FROM ho_so h 
       JOIN nganh n ON h.nganh_id = n.id 
       WHERE h.nguoi_dung_id = ? 
       ORDER BY h.created_at DESC`,
      [req.user.userId]
    );
    res.json(hoSo);
  } catch (error) {
    console.error('Lỗi lấy danh sách hồ sơ:', error);
    res.status(500).json({ message: 'Lỗi server' });
  }
});

// Lấy chi tiết một hồ sơ
router.get('/:id', authenticate, async (req, res) => {
  try {
    const { id } = req.params;
    const [hoSo] = await pool.execute(
      `SELECT h.*, n.ten_nganh, n.ma_nganh, n.mo_ta, n.chi_tieu, n.diem_chuan
       FROM ho_so h 
       JOIN nganh n ON h.nganh_id = n.id 
       WHERE h.id = ? AND h.nguoi_dung_id = ?`,
      [id, req.user.userId]
    );

    if (hoSo.length === 0) {
      return res.status(404).json({ message: 'Không tìm thấy hồ sơ' });
    }

    res.json(hoSo[0]);
  } catch (error) {
    console.error('Lỗi lấy chi tiết hồ sơ:', error);
    res.status(500).json({ message: 'Lỗi server' });
  }
});

export default router;

