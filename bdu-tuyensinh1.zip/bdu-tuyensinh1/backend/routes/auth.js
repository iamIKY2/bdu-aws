import express from 'express';
import jwt from 'jsonwebtoken';
import pool from '../config/database.js';

const router = express.Router();

// Đăng ký tài khoản mới
router.post('/register', async (req, res) => {
  try {
    const { email, password, hoTen, soDienThoai } = req.body;

    // Kiểm tra dữ liệu đầu vào
    if (!email || !password || !hoTen || !soDienThoai) {
      return res.status(400).json({ message: 'Vui lòng điền đầy đủ thông tin' });
    }

    // Kiểm tra email đã tồn tại chưa
    const [existingUsers] = await pool.execute(
      'SELECT * FROM nguoi_dung WHERE email = ?',
      [email]
    );

    if (existingUsers.length > 0) {
      return res.status(400).json({ message: 'Email đã được sử dụng' });
    }

    // Lưu mật khẩu dạng plain text (không mã hóa)
    // Tạo tài khoản mới
    const [result] = await pool.execute(
      'INSERT INTO nguoi_dung (email, password, ho_ten, so_dien_thoai, vai_tro) VALUES (?, ?, ?, ?, ?)',
      [email, password, hoTen, soDienThoai, 'thi_sinh']
    );

    // Tạo token
    const token = jwt.sign(
      { userId: result.insertId, email, vaiTro: 'thi_sinh' },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'Đăng ký thành công',
      token,
      user: {
        id: result.insertId,
        email,
        hoTen,
        vaiTro: 'thi_sinh'
      }
    });
  } catch (error) {
    console.error('Lỗi đăng ký:', error);
    res.status(500).json({ message: 'Lỗi server khi đăng ký' });
  }
});

// Đăng nhập
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Vui lòng nhập email và mật khẩu' });
    }

    // Tìm người dùng
    const [users] = await pool.execute(
      'SELECT * FROM nguoi_dung WHERE email = ?',
      [email]
    );

    if (users.length === 0) {
      return res.status(401).json({ message: 'Email hoặc mật khẩu không đúng' });
    }

    const user = users[0];

    // Kiểm tra mật khẩu (so sánh plain text)
    if (user.password !== password) {
      return res.status(401).json({ message: 'Email hoặc mật khẩu không đúng' });
    }

    // Tạo token
    const token = jwt.sign(
      { userId: user.id, email: user.email, vaiTro: user.vai_tro },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Đăng nhập thành công',
      token,
      user: {
        id: user.id,
        email: user.email,
        hoTen: user.ho_ten,
        vaiTro: user.vai_tro
      }
    });
  } catch (error) {
    console.error('Lỗi đăng nhập:', error);
    res.status(500).json({ message: 'Lỗi server khi đăng nhập' });
  }
});

export default router;

