// Script để generate hash password cho admin
// Sử dụng: node scripts/generatePassword.js <password>

import bcrypt from 'bcryptjs';

const password = process.argv[2] || 'admin123';

bcrypt.hash(password, 10)
  .then(hash => {
    console.log('Password:', password);
    console.log('Hash:', hash);
    console.log('\nSQL Update:');
    console.log(`UPDATE nguoi_dung SET password = '${hash}' WHERE email = 'admin@bdu.edu.vn';`);
  })
  .catch(err => {
    console.error('Error:', err);
  });

